package com.cg.TestBooking;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.exception.SeatsNotAvailableException;
import com.cg.ems.exception.UserNotLoggedInException;
import com.cg.ems.pojo.Booking;
import com.cg.ems.pojo.BookingVO;
import com.cg.ems.service.BookingService;
import com.cg.ems.service.BookingServiceImpl;


public class BookingTestCases {

	static GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");

	static BookingService bService = ctx.getBean("bookingService",BookingService.class);


/*process booking*/

	@Test
	public  void BookingShouldFailWhenTheUserIsNotLoggedIn() {

		try{
		Booking booking=new Booking();
		
		booking.setUserId(0);
		booking.setEventId(1);
		booking.setTicketId(5);
		booking.setNoOfTickets(1);
		bService.processBooking(booking);
		}
		catch(Exception e){}


	}

	@Test
	public void BookingShouldFailWhenTheSeatsAreNotAvailable() {

		try{
			Booking booking=new Booking();
			
			booking.setUserId(1);
			booking.setEventId(1);
			booking.setTicketId(1);
			booking.setNoOfTickets(1);
			bService.processBooking(booking);
			}
			catch(Exception e){}

	}



	@Test
	public void BookingIsSuccessfullWhenThereIsValidTransaction(){

		try{
		Booking booking=new Booking();
		booking.setUserId(1);
		booking.setEventId(1);
		booking.setTicketId(1);
		booking.setNoOfTickets(1);
		Booking booking2=bService.processBooking(booking);
		int i=booking2.getBookingId();
		BookingVO bookingVO=bService.finalizeBooking(i, "TXNID");

		Assert.assertTrue(bookingVO.getBookingStatus().equals("booked"));
		}
		catch(Exception e){}

	}


	@Test
	public void BookingIsDoneForTheEventSelectedByTheUser(){
		
		try{
			Booking booking=new Booking();
				booking.setUserId(1);
			booking.setEventId(1);
			booking.setTicketId(1);
			booking.setNoOfTickets(1);
			Booking booking2=bService.processBooking(booking);
			int i=booking2.getBookingId();
			BookingVO bookingVO=bService.finalizeBooking(i, "TXNID");
			Assert.assertTrue(bookingVO.getEventvo().getEventId()==(booking.getEventId()));
			}
			catch(Exception e){}

	}


	@Test
	public void BookingIsdoneOnlyForTypeOfSeatSelected(){
		
		try{
			Booking booking=new Booking();
			
			booking.setUserId(1);
			booking.setEventId(1);
			booking.setTicketId(1);
			booking.setNoOfTickets(1);
			Booking booking2=bService.processBooking(booking);
			int i=booking2.getBookingId();
			BookingVO bookingVO=bService.finalizeBooking(i, "TXNID");
			Assert.assertTrue(bookingVO.getTickettype().getTicketId()==(booking.getTicketId()));
			}
			catch(Exception e){}
	}



	/*finalizeBooking*/

	@Test
	public void UserShouldGetTotalAmountOfTicketsBooked(){
		
		
		try{
			Booking booking=new Booking();
			
			booking.setUserId(1);
			booking.setEventId(1);
			booking.setTicketId(1);
			booking.setNoOfTickets(1);
			Booking booking2=bService.processBooking(booking);
			int i=booking2.getBookingId();
			BookingVO bookingVO=bService.finalizeBooking(i, "TXNID");
			Assert.assertTrue(bookingVO.getTotalAmount()>0);
			}
			catch(Exception e){}

	}
	
	
	@Test
	public void  OneUserCanBookMultipleTickets(){
		
		
		try{
			Booking booking=new Booking();
			booking.setUserId(1);
			booking.setEventId(1);
			booking.setTicketId(1);
			booking.setNoOfTickets(2);
			Booking booking2=bService.processBooking(booking);
			int i=booking2.getBookingId();
			BookingVO bookingVO=bService.finalizeBooking(i, "TXNID");
			Assert.assertTrue(bookingVO.getNoOfTickets()>0);
			}
			catch(Exception e){}

	}



	@Test
	public void UserShouldGetAllDetailsRegardingBooking() throws UserNotLoggedInException, SeatsNotAvailableException{
		
		
		
	
		try{
			Booking booking=new Booking();
			booking.setUserId(1);
			booking.setEventId(1);
			booking.setTicketId(1);
			booking.setNoOfTickets(2);
			Booking booking2=bService.processBooking(booking);
			
			BookingVO bookingVO=bService.finalizeBooking(booking2.getBookingId(),"TXNID");
			
			Assert.assertTrue(bookingVO.getTotalAmount()>0 && bookingVO.getTickettype().getTicketId()>0 && bookingVO.getNoOfTickets()>0 && (!(bookingVO.getTransactionId().equals(null))) );
		}catch(Exception e){}
}
	
}
