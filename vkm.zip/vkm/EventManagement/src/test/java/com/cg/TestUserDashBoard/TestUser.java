package com.cg.TestUserDashBoard;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.service.UserServiceInter;

public class TestUser {

	
	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	UserServiceInter user=ctx.getBean("userServiceIn",UserServiceInter.class);

@Test
public void displayUserAddedEventForValidUSer()
{
	user.getUserAddedEvents(1);
}
@Test
public void doNotdisplayUserAddedEventForInvValidUSer()
{
	assertFalse(user.getUserAddedEvents(1667079).size()>=1);
}
@Test
public  void ddisplayUserProfileValidUser()
{
	user.getUserProfile(1);
}
@Test
public  void doNotdisplayUserProfileInValidUser()
{
	assertFalse(user.getUserProfile(1).getFirstName()==null);
}

@Test
public void  displayUserBookedEventForValidUser()
{
	
	user.getUserBookedEvents(1);
}

@Test
public void  doNotDisplayUserBookedEventForInValidUser()
{
	
	assertFalse(user.getUserBookedEvents(648).size()>=1);
}

}
