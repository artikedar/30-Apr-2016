package com.cg.TestSearch;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.service.EventService;
import com.cg.ems.service.EventServiceImpl;
import com.cg.ems.service.SearchService;
import com.cg.ems.service.SearchServiceImpl;

public class SearchTestCasesForCategory 
{
	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	SearchService sserv = ctx.getBean("sservice",SearchServiceImpl.class);
	
	
	@Test
	public void displayEventsWithValidCategoriesOnly()
	{
		sserv.findByCategory("Music");
		
	}
	@Test
	public void doNotDisplayEventForInvalidCategory()
	{
		assertFalse(sserv.findByCategory("abc").size()>=1);
	}

	@Test
	public void doNotDisplayEventForNullCategory()
	{
		assertFalse(sserv.findByCategory(null).size()>=1);
	}


}
