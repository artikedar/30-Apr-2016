package org.angular.spring.controller;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.angular.spring.dao.DataSetup;
import org.angular.spring.security.TokenUtils;
import org.angular.spring.view.UserView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

@Component
@Path("/user/{username}/{password}")
public class UserResource {

	@Autowired
	private UserDetailsService userService;

	@Autowired
	@Qualifier("authenticationManager")
	private AuthenticationManager authManager;
	@Autowired
	private DataSetup ds;
	@GET 
	@Produces(MediaType.APPLICATION_JSON)
	public UserView authenticate(@PathParam("username") String username,@PathParam("password") String password) {
	
		UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username, password);
		System.out.println(authenticationToken);
		Authentication authentication = this.authManager.authenticate(authenticationToken);
		
		SecurityContextHolder.getContext().setAuthentication(authentication);

		Map<String, Boolean> roles = new HashMap<String, Boolean>();

		UserDetails userDetails = this.userService.loadUserByUsername(username);

		for (GrantedAuthority authority : userDetails.getAuthorities()) {
			roles.put(authority.toString(), Boolean.TRUE);
		}
        
		UserView uv= new UserView(userDetails.getUsername(), roles, TokenUtils.createToken(userDetails),ds.getUserId(userDetails.getUsername()));
	    System.out.println(uv); 
		return uv;
	}

}
