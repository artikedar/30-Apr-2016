package org.angular.spring;

public class JsonViews {

	public static class Login {}

	public static class Admin extends Login {}

}