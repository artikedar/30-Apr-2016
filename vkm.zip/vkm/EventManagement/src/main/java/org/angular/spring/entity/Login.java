package org.angular.spring.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import org.angular.spring.JsonViews;
import org.codehaus.jackson.map.annotate.JsonView;

@Entity
@SuppressWarnings("serial")
public class Login implements Serializable {

	@Id
	@Column(name="login_id")
	@GeneratedValue
	private Long loginId;

	@Column
	private String username;

	@Column
	private String password;

	@Column
	private Boolean enabled;

	@ManyToMany(fetch=FetchType.EAGER)
	@JoinTable(name="user_role", joinColumns=@JoinColumn(name="id_user"), inverseJoinColumns=@JoinColumn(name="id_role"))
	private Set<Role> roles;

	public Login() {
		setEnabled(true);
	}

	@JsonView(JsonViews.Admin.class)
	public Long getLoginId() {
		return this.loginId;
	}

	@JsonView(JsonViews.Login.class)
	public String getUsername() {
		return username;
	}

	@JsonView(JsonViews.Admin.class)
	public String getPassword() {
		return password;
	}
	
	public Boolean getEnabled() {
		return enabled;
	}
	
	@JsonView(JsonViews.Login.class)
	public Set<Role> getRoles() {
		return roles;
	}
	
	public void setLoginId(Long userid) {
		this.loginId = userid;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}
	
	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return String.format("User[%s]", this.username);
	}

}