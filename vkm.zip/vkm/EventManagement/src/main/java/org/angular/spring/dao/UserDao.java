package org.angular.spring.dao;

import java.util.List;

import org.angular.spring.entity.Login;

public interface UserDao {

	List<Login> findAll();
	Login find(Long id);
	Login save(Login obj);
	void delete(Long id);
	List userIdByName(String name);

}