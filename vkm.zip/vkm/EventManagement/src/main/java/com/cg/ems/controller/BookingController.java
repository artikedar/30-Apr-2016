package com.cg.ems.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.exception.SeatsNotAvailableException;
import com.cg.ems.exception.UserNotLoggedInException;
import com.cg.ems.pojo.Booking;
import com.cg.ems.pojo.BookingResponse;
import com.cg.ems.pojo.BookingVO;
import com.cg.ems.service.BookingService;



@RestController
public class BookingController {

	
	@Autowired
	BookingService bookingService;


	@RequestMapping(value="/bookTicket",method=RequestMethod.POST)
	public @ResponseBody BookingResponse bookTicket(@RequestBody Booking booking) throws UserNotLoggedInException, SeatsNotAvailableException
	{
//		Booking booking=new Booking();
//		booking.setEventId(1);
//		booking.setNoOfTickets(2);
//		booking.setUserId(1);
//		booking.setTicketId(1);

		Booking booking1=bookingService.processBooking(booking);

	
		BookingResponse bookingResponse=new BookingResponse();
		
		bookingResponse.setBookingId(booking1.getBookingId());
		bookingResponse.setUrl("http://din51002653:8181/PaymentGateway/redirect?amount="+booking1.getTotalAmount()+"&merchantId=4&bookingId="+booking1.getBookingId());
		
		return bookingResponse;
	}
	
	
	@RequestMapping(value="/finalizeBooking")
	public BookingVO result(int bookingId,String transactionId,String status){

		if(status.equalsIgnoreCase("Success")){
			
			BookingVO bookingVO=bookingService.finalizeBooking(bookingId, transactionId);
			return bookingVO;
			
		}
		return null;

		
	}
}
