package com.cg.ems.service;

import java.util.List;

import com.cg.ems.pojo.BookingVO;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.pojo.User;

public interface AdminService {
	List<EventVO> findApproveEvents();
	List<BookingVO> getAllTransaction();
	boolean approveEvent(int eventId);
	boolean rejectEvent(int eventId);
	User getAdminDetails(int userId);
}
