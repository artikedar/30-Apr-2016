package com.cg.main;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.pojo.Booking;
import com.cg.ems.pojo.BookingVO;
import com.cg.ems.service.BookingService;

public class BookingClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
		
		BookingService bServ = ctx.getBean("bookingService",BookingService.class);
	/*	Booking booking=new Booking();
		booking.setEventId(1);
		booking.setNoOfTickets(2);
		booking.setUserId(1);
		booking.setTicketId(2);
		booking=bServ.processBooking(booking);
		System.out.println(booking);*/
		BookingVO bvo=bServ.finalizeBooking(39, "a");

		System.out.println(bvo);
	}

}
