package com.cg.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.pojo.BookingVO;
import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.pojo.User;
import com.cg.ems.service.AdminService;
import com.cg.ems.service.SearchService;

@RestController
public class AdminController{


	@Autowired
	AdminService aservice;
	@RequestMapping(value="/find")
	public List<EventVO> findAllapprovedevents()
	{

		return aservice.findApproveEvents();
	}


	@RequestMapping(value="/get")
	public List<BookingVO> getAllTransactions()
	{

		return aservice.getAllTransaction();
	}


	@RequestMapping(value="/approve")
	public boolean approveEvent(String eventId)
	{

		try{
			aservice.approveEvent(Integer.parseInt(eventId));
			return true;
		}
		catch(Exception e){
			return false;
		}
	}

	@RequestMapping(value="/reject")
	public boolean rejectEvent(String eventId)
	{
		try{
			aservice.rejectEvent(Integer.parseInt(eventId));
			return true;
		}
		catch(Exception e){
			return false;
		}

	}
	@RequestMapping(value="/adetails")
	public User findAdminProfile(int userId)
	{

		return aservice.getAdminDetails(userId);
	}

}
