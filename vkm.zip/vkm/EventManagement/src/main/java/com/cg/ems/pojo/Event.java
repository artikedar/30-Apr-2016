package com.cg.ems.pojo;

import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table
public class Event {
	 @Id
	 @Column(name="event_id",unique = true, nullable = false)
	 @GeneratedValue(strategy=GenerationType.AUTO)
	private int eventId;
	 
	 @Column(name="event_name")
	 private String eventName;
	
	 private String description;
	
	 @Column(name="date_start")
	
	private String dateStart;
	 
	 @Column(name="date_end")
	 
	private String dateEnd;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "address_id")
	private Address address;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "album_id")
	private Album album;
	
	 @OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
		@JoinColumn(name="event_id",nullable = false)
	private Set<Contact> contact;
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="category_id")
	private Category category;
	
	 @ManyToMany(cascade = CascadeType.ALL,fetch=FetchType.LAZY)
	    @JoinTable(name = "event_performer", joinColumns = {@JoinColumn(name = "event_id", referencedColumnName = "event_id")}, inverseJoinColumns ={@JoinColumn(name = "performer_id", referencedColumnName = "performer_id")})
	private Set<Performer> performer;
	 
	private String status;
	
	
	@Column(name="user_id")
	private int userId;
	
	 @OneToMany( cascade=CascadeType.ALL,fetch=FetchType.LAZY)
		@JoinColumn(name="event_id",nullable = false)
    private Set<TicketType> tickettype;
	
	 @OneToMany( cascade=CascadeType.ALL,fetch=FetchType.LAZY)
		@JoinColumn(name="event_id",nullable = false)
    private Set<Schedule> schedule;
	
	@Column(name="avg_rating")
    private float avgRating; 
	
	@Column(name="delete_date",insertable=false,updatable=true,nullable=true)
	private Timestamp deleteDate;
   
    
	public Timestamp getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(Timestamp deleteDate) {
		this.deleteDate = deleteDate;
	}

	

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Set<Schedule> getSchedule() {
		return schedule;
	}

	public void setSchedule(Set<Schedule> schedule) {
		this.schedule = schedule;
	}

	public float getAvgRating() {
		return avgRating;
	}

	public void setAvgRating(float avgRating) {
		this.avgRating = avgRating;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDateStart() {
		return dateStart;
	}

	public void setDateStart(String dateStart) {
		this.dateStart = dateStart;
	}

	public String getDateEnd() {
		return dateEnd;
	}

	public void setDateEnd(String dateEnd) {
		this.dateEnd = dateEnd;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Album getAlbum() {
		return album;
	}

	public void setAlbum(Album album) {
		this.album = album;
	}

	

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Set<Performer> getPerformer() {
		return performer;
	}

	public void setPerformer(Set<Performer> performer) {
		this.performer = performer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	

	public Set<Contact> getContact() {
		return contact;
	}

	public void setContact(Set<Contact> contact) {
		this.contact = contact;
	}

	public Set<TicketType> getTickettype() {
		return tickettype;
	}

	public void setTickettype(Set<TicketType> tickettype) {
		this.tickettype = tickettype;
	}

	

/*<<<<<<< .mine
	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", eventName=" + eventName
				+ ", description=" + description + ", dateStart=" + dateStart
				+ ", dateEnd=" + dateEnd + ", category=" + category
				+ ", status=" + status + ", avgRating=" + avgRating
				+ ", deleteDate=" + deleteDate + "]";
	}

=======*/
	/*@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", eventName=" + eventName
				+ ", description=" + description + "]";
	}*/
}
