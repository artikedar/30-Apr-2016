package com.cg.ems.service;

import java.util.List;

import com.cg.ems.pojo.Comment;
import com.cg.ems.pojo.User;

public interface CommentService {
	public Comment saveComment(Comment c) throws Exception;
	public List<Comment> getAll(int id);
	public String deleteComment(int commentId , int userId) ;
	public Comment findComment();
	public User findUser(int userId);
}
