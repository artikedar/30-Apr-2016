package com.cg.ems.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.Rating;
import com.cg.ems.pojo.RatingVO;

public interface RatingRepo extends JpaRepository<Rating, Integer>{

	@Query(value="select new com.cg.ems.pojo.RatingVO(r.value,count(r.value)) from Rating r where r.eventId=? group by r.value order by r.value")
	public List<RatingVO> searchRatings(int eventId);
	@Query(value="Select AVG(r.value) from Rating r where r.eventId=?")
	public float updateRating(int eventId);
	

	
}