package com.cg.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.pojo.EventVO;
import com.cg.ems.repo.AdminRepo;
import com.cg.ems.repo.SearchRepo;
import com.cg.ems.service.SearchService;

@RestController
public class SearchController {
	
	@Autowired
	SearchService sservice;
	@RequestMapping(value="/spopularity")
	public List<EventVO> searchByPopularity()
	{
		
		return sservice.findByRating();
	}
	@RequestMapping(value="/sperformer")
	public List<EventVO> searchByPerformer(String firstName,String lastName)
	{
		return sservice.findByPerformer(firstName, lastName);
	}
	@RequestMapping(value="/scategory")
	public List<EventVO> searchByCategory(String name)
	{

		return sservice.findByCategory(name);
	}
	@RequestMapping(value="/scity")
	public List<EventVO> searchByCity(String city)
	{
		return sservice.findByCity(city);
	}
	@RequestMapping(value="/sdate")
	public List<EventVO> searchByDate(String date)
	{
		return sservice.findByDate(date);
	}
	@RequestMapping(value="/sname")
	public List<EventVO> searchByname(String eventName)
	{
		return sservice.findByName(eventName);
	}

}
