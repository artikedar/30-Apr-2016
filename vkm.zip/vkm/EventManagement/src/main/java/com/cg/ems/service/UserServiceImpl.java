package com.cg.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.pojo.BookingVO;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.pojo.User;
import com.cg.ems.repo.UserRepo;

@Service(value="userServiceIn")
public class UserServiceImpl implements UserServiceInter {

	@Autowired
	UserRepo urepo;
	@Override
	public User getUserProfile(int id) {
		return urepo.getUserProfile(id);
	}

	@Override
	public List<EventVO> getUserAddedEvents(int id){
		List<EventVO> evo = urepo.getUserAddedEvents(id);
		for(EventVO ev:evo){
			ev.setPhotoCollections(urepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}


	@Override
	public List<BookingVO> getUserBookedEvents(int id) {
		// TODO Auto-generated method stub
		List<BookingVO> bol=urepo.getUserBookedEvents(id);
		EventVO ev;
		for(BookingVO bo:bol){
			bo.setContact(urepo.contactList(bo.getEventId()));
			bo.setUser(urepo.userOfBooking(bo.getBookingId()));
			bo.setTickettype(urepo.tickettypeForBooking(bo.getTicketId()));
			ev=urepo.queryByEventId(bo.getEventId());
			System.out.println(urepo.photocollectionList(ev.getAlbumId()));
			ev.setPhotoCollections(urepo.photocollectionList(ev.getAlbumId()));
			bo.setEventvo(ev);
		}
		return bol;
	}

}
