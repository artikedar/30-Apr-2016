package com.cg.ems.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.ems.pojo.User;

public interface UserRepoForSigunUp extends JpaRepository<User, Integer> {
	@Query(value = "SELECT u FROM User u WHERE u.username=?1" )	
	User findByUserName(String username);

}
