package com.cg.ems.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.ems.exception.SeatsNotAvailableException;
import com.cg.ems.exception.UserNotLoggedInException;
import com.cg.ems.pojo.Booking;
import com.cg.ems.pojo.BookingVO;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.pojo.TicketType;
import com.cg.ems.repo.BookingRepo;
import com.cg.ems.repo.EventVoRepo;
import com.cg.ems.repo.TicketTypeRepo;

@Service(value="bookingService")
public class BookingServiceImpl implements BookingService{


	@Autowired
	EventVoRepo eventVORepo;
	@Autowired
	BookingRepo bookingrepo;
	@Autowired
	TicketTypeRepo ticketTypeRepo;



	public Booking processBooking(Booking booking) throws UserNotLoggedInException,SeatsNotAvailableException {
		
		if(booking.getUserId()==0){
			throw new UserNotLoggedInException();
			
		}

		else{
		
			
			TicketType ticketType=bookingrepo.tickettypeForBooking(booking.getTicketId());
			

				
				float totalAmount=ticketType.getPrice()*booking.getNoOfTickets();
				booking.setTotalAmount(totalAmount);
				booking.setBookingStatus("not booked");

				Booking booking2=bookingrepo.save(booking);
				return booking2;
			}
		
	}
	

	public BookingVO finalizeBooking(int bookingId, String transactionId) {
		if(!(transactionId.equals(null))){
		Booking booking=bookingrepo.bookingByBookingId(bookingId);
		booking.setTransactionId(transactionId);
		booking.setBookingStatus("booked");
		Booking booking1=bookingrepo.save(booking);


		TicketType ticketType1=ticketTypeRepo.findOne(booking1.getTicketId());
		ticketType1.setAvailableSeats((ticketType1.getAvailableSeats())-(booking1.getNoOfTickets()));
		TicketType ticketType2=ticketTypeRepo.save(ticketType1);

		BookingVO bokingVO=bookingrepo.BookingVo(booking1.getBookingId());
		EventVO ev;
		bokingVO.setContact(bookingrepo.contactList(booking1.getEventId()));
		bokingVO.setUser(bookingrepo.userOfBooking(booking1.getUserId()));
		bokingVO.setTickettype(bookingrepo.tickettypeForBooking(booking1.getTicketId()));
		ev=bookingrepo.queryByEventId(booking1.getEventId());
		ev.setPhotoCollections(bookingrepo.photocollectionList(ev.getAlbumId()));
		bokingVO.setEventvo(ev);

		return bokingVO;
		}else return null;
	}

@Override
	public BookingVO getBookingObject(int bookingId) {
		// TODO Auto-generated method stub
		Booking booking1=bookingrepo.bookingByBookingId(bookingId);


		BookingVO bokingVO=bookingrepo.BookingVo(booking1.getBookingId());
		EventVO ev;
		bokingVO.setContact(bookingrepo.contactList(booking1.getEventId()));
		bokingVO.setUser(bookingrepo.userOfBooking(booking1.getUserId()));
		bokingVO.setTickettype(bookingrepo.tickettypeForBooking(booking1.getTicketId()));
		ev=bookingrepo.queryByEventId(booking1.getEventId());
		ev.setPhotoCollections(bookingrepo.photocollectionList(ev.getAlbumId()));
		bokingVO.setEventvo(ev);

		return bokingVO;
	}

}
