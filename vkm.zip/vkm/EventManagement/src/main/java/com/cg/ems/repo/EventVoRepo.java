package com.cg.ems.repo;

import java.util.List;

import javax.persistence.QueryHint;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;

import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.EventVO;

public interface EventVoRepo extends JpaRepository<Event, Integer> {

	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab  where e.eventId=? and e.dateStart > now() and  (e.deleteDate=0 or e.deleteDate=null) ")
	public List<EventVO> queryByEventId(int eventId);
	
	@Query(value="select p.photoUrl from com.cg.ems.pojo.PhotoCollection p where p.albumId=?")
	public List<String> photocollectionList(int id);
	
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab where e.dateStart > now() and  (e.deleteDate=0 or e.deleteDate=null) and e.status='Approved' order by e.avgRating DESC")
	public List<EventVO> popularEvent(Pageable pageable);
	
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab where e.dateStart > now() and  (e.deleteDate=0 or e.deleteDate=null) and e.status='Approved' order by e.dateStart ASC")
	public List<EventVO> upcomingEvent(Pageable pageable);
}
