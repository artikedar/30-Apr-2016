package com.cg.main;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.pojo.Loginn;
import com.cg.ems.pojo.User;
import com.cg.ems.pojo.UserRole;
import com.cg.ems.service.LoginServiceImpl;
import com.cg.ems.service.LoginServiceInter;
import com.cg.ems.service.UserRoleServiceImpl;
import com.cg.ems.service.UserRoleServiceInter;
import com.cg.ems.service.UserServcieImplForSignUp;
import com.cg.ems.service.UserServiceInterForSignUp;



public class SignUpClient {
	

	
	
	public static void main(String []args) throws Exception{
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
		UserServiceInterForSignUp uservice = ctx.getBean("userSignUpService",UserServcieImplForSignUp.class);
		LoginServiceInter lservice = ctx.getBean("loginService",LoginServiceImpl.class);
		UserRoleServiceInter urservice = ctx.getBean("userRoleService",UserRoleServiceImpl.class);

		User u = new User();
		u.setFirstName("Praneetvhh");
		u.setLastName("Paidi");
		u.setPhoneNo("7095335444");
		u.setUsername("new");
		u.setEmail("praneeth.paidi@dfgamil.com");
		
		u = uservice.register(u);
		
		Loginn l=new Loginn();
		l.setUserName("new");
		l.setPassWord("PP");
		l=lservice.saveLogin(l);
		
		UserRole ur = new UserRole();
		ur.setUserId(l.getLoginId());
		ur.setRoleId(1);
		System.out.println(urservice.saveRole(ur));
		
		
	}

}
