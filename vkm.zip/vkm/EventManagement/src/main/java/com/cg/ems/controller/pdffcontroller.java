package com.cg.ems.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.pojo.BookingVO;
import com.cg.ems.pojo.Rating;
import com.cg.ems.service.BookingService;



@Controller
public class pdffcontroller {
@Autowired
BookingService bserv;
 @RequestMapping(value = "/gpdf", method = RequestMethod.GET)
 ModelAndView generatePdf(HttpServletRequest request, HttpServletResponse response) throws Exception {
 System.out.println(request.getParameter("bookingId"));
BookingVO bvo= bserv.getBookingObject(Integer.parseInt(request.getParameter("bookingId")));

  ModelAndView modelAndView = new ModelAndView("pdfView", "command",bvo);
  System.out.println(modelAndView);
  return modelAndView;
 }
}


