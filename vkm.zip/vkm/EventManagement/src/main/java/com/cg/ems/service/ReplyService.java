package com.cg.ems.service;

import com.cg.ems.pojo.Reply;



public interface ReplyService {
	public Reply saveReply(Reply r) throws Exception;

}
