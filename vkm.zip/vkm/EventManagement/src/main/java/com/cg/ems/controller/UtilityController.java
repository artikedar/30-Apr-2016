package com.cg.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.pojo.EventVO;
import com.cg.ems.service.EventService;

@RestController
public class UtilityController {
	@Autowired
	EventService eventService;
	@Autowired
	
	

	@RequestMapping(value="/listOfCategory")
	public List<String> allCategory(){
		return eventService.allCategory();
	}
	@RequestMapping(value="/listOfCity")
	public List<String> allCity(){
		return eventService.allCity();
	}
	@RequestMapping(value="/listOfEventsName")
	public List<String> allEvents(){
		return eventService.allEvents();
	}
	@RequestMapping(value="/listOfPerformers")
	public List<String> allPerformers(){
		return eventService.allPerformers();
	}
	@RequestMapping(value="/popularEvents")
	public List<EventVO> popularEventsList(){
		return eventService.popularEvents();
	}
	
	@RequestMapping(value="/upcomingEvents")
	public List<EventVO> upcomingEventsList(){
		return eventService.upcomingEventList();
	}
	
	
}
